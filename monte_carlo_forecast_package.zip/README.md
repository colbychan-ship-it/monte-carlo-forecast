# Monte Carlo Delivery Time Forecast

This Streamlit app allows you to upload delivery time data as a CSV, run a Monte Carlo simulation to forecast delivery times, and visualize the results.

## Prerequisites

- GitHub account
- Streamlit account (login with GitHub)

## How to Deploy

1. Create a new GitHub repository (e.g., `monte-carlo-forecast`)
2. Upload the following files:
    - `monte_carlo_forecaster.py`
    - `requirements.txt`
    - `README.md`
3. Push the repo to GitHub.
4. Go to [Streamlit Cloud](https://streamlit.io/cloud), click "Deploy an app"
5. Connect your GitHub repo, select branch `main`, and file path `monte_carlo_forecaster.py`
6. Click "Deploy"
7. Within ~30 seconds, your app will be live and shareable!

## Usage

- Upload a CSV file with a column named `delivery_time`
- Adjust the number of simulations slider
- View the forecast histogram and summary statistics

---

Enjoy forecasting! 🚀
